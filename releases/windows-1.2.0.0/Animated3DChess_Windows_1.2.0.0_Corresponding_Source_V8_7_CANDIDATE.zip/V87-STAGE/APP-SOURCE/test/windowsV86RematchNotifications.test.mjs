import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {runInNewContext} from 'node:vm';
import {createRematchNotifications, noticeMatchesView, shouldAutoOpenRematch, getRematchNoticeCopy} from '../src/rematchNotifications.mjs';
const CODE='ABCDEFGH23';
function view(revision=1, offer=null, options={}) {
  const {round=1,status='finished',side='w',code=CODE,sessionEpoch=1,connection='connected',rematchReady=true,error=null,both=true}=options;
  return {code,side,sessionEpoch,connection,rematchReady,error,room:{code,revision,round,status,whiteJoined:true,blackJoined:both,rematchOfferedBy:offer}};
}
for(const side of ['w','b']) test(`incoming offer for ${side}, duplicate and language-independent identity`,()=>{
  const t=createRematchNotifications(), other=side==='w'?'b':'w';
  assert.equal(t.observe(view(1,null,{side})),null);
  const n=t.observe(view(2,other,{side})); assert.equal(n.kind,'incoming');
  assert.equal(shouldAutoOpenRematch(n,0,false),true);
  assert.equal(t.observe(view(2,other,{side})),n);
  assert.equal(t.observe(view(3,other,{side})),n);
  assert.equal(shouldAutoOpenRematch(n,n.id,false),false);
  assert.equal(noticeMatchesView(n,view(3,other,{side})),true);
});
test('first observation after restart with live offer alerts, own offer does not',()=>{
  assert.equal(createRematchNotifications().observe(view(2,'b')).kind,'incoming');
  assert.equal(createRematchNotifications().observe(view(2,'w')),null);
});
test('outgoing cleared in same finished round creates one status, no board action',()=>{
  const t=createRematchNotifications(); t.observe(view(1,'w'));
  const n=t.observe(view(2));assert.equal(n.kind,'offer-cleared');
  assert.equal(t.observe(view(3)),n); assert.equal(noticeMatchesView(n,view(3)),true);
  assert.equal(t.observe(view(4,'w')),null);
  assert.notEqual(t.observe(view(5)).id,n.id);
});
test('receiver declining is not notified as sender; a renewed offer alerts again',()=>{
  const t=createRematchNotifications(), a=t.observe(view(2,'b'));
  assert.equal(t.observe(view(3)),null);
  const b=t.observe(view(4,'b'));assert.equal(b.kind,'incoming');assert.notEqual(a.id,b.id);
});
test('acceptance and seat rotation never produce decline; subsequent round offers work',()=>{
  const t=createRematchNotifications();t.observe(view(2,'w'));
  assert.equal(t.observe(view(3,null,{round:2,side:'b',status:'playing'})),null);
  const n=t.observe(view(4,'w',{round:2,side:'b'}));assert.equal(n.kind,'incoming');
  assert.equal(t.observe(view(5,null,{round:3,side:'w',status:'playing'})),null);
});
test('disconnected cached state hidden, reconnect same offer does not create duplicate',()=>{
  const t=createRematchNotifications(), n=t.observe(view(2,'b'));
  assert.equal(t.observe(view(2,'b',{connection:'disconnected',rematchReady:false})),null);
  assert.equal(t.observe(view(2,'b',{connection:'connecting',rematchReady:false})),null);
  assert.equal(t.observe(view(2,'b')),n);assert.equal(shouldAutoOpenRematch(n,n.id,false),false);
});
test('offer received while offline only alerts after confirmed reconnect',()=>{
  const t=createRematchNotifications();t.observe(view());
  assert.equal(t.observe(view(2,'b',{connection:'connecting',rematchReady:false})),null);
  assert.equal(t.observe(view(2,'b')).kind,'incoming');
});
test('reconnect with cleared own offer is notice, network failure alone is not',()=>{
  const t=createRematchNotifications();t.observe(view(2,'w'));
  assert.equal(t.observe(view(2,'w',{connection:'disconnected'})),null);
  assert.equal(t.observe(view(3)).kind,'offer-cleared');
});
test('no stale incoming offer after acceptance during disconnection',()=>{
  const t=createRematchNotifications();const n=t.observe(view(2,'b'));
  assert.equal(t.observe(view(2,'b',{connection:'disconnected'})),null);
  assert.equal(t.observe(view(3,null,{round:2,side:'b',status:'playing'})),null);
  assert.equal(t.observe(view(2,'b')),null);
  assert.equal(noticeMatchesView(n,view(3,null,{round:2,side:'b',status:'playing'})),false);
});
test('explicit leave, same code reused with new epoch and cross-room changes',()=>{
  const t=createRematchNotifications(), a=t.observe(view(2,'b'));
  assert.equal(t.observe({code:null}),null);
  const b=t.observe(view(2,'b',{sessionEpoch:2}));assert.notEqual(b.id,a.id);
  assert.equal(noticeMatchesView(a,view(2,'b',{sessionEpoch:2})),false);
  assert.equal(t.observe(view(1,null,{code:'ZXCVBNMA23',sessionEpoch:3})),null);
});
test('expiry, freeze, missing legacy field and missing opponent do not produce false declines',()=>{
  for(const opts of [{connection:'expired'},{error:'invalid-server-state'},{both:false}]) {
    const t=createRematchNotifications();t.observe(view(2,'w'));assert.equal(t.observe(view(3,null,opts)),null);
  }
  const t=createRematchNotifications();t.observe(view(2,'w'));const legacy=view(3);delete legacy.room.rematchOfferedBy;
  assert.equal(t.observe(legacy),null);
});
test('stale revision, conflicting same revision, stale round and unverified snapshot do not alert',()=>{
  const t=createRematchNotifications();t.observe(view(5,null,{round:2}));
  assert.equal(t.observe(view(4,'b',{round:2})),null);
  assert.equal(t.observe(view(5,'b',{round:2})),null);
  assert.equal(t.observe(view(6,'b',{round:1})),null);
  assert.equal(t.observe(view(6,'b',{round:2,rematchReady:false})),null);
  assert.equal(t.observe(view(6,'b',{round:2})).kind,'incoming');
});
test('competing dialog defers once, dismissed panel does not reopen',()=>{
  const n=createRematchNotifications().observe(view(2,'b'));
  assert.equal(shouldAutoOpenRematch(n,0,true),false);assert.equal(shouldAutoOpenRematch(n,0,false),true);
  assert.equal(shouldAutoOpenRematch(n,n.id,false),false);
});
test('all five languages, fallback and distinct incoming/cleared text',()=>{
  const values=['en','hr','de','it','es'].map(getRematchNoticeCopy);
  for(const c of values) {assert.ok(c.incoming&&c.cleared&&c.open);assert.notEqual(c.incoming,c.cleared);}
  assert.equal(new Set(values.map(x=>x.incoming)).size,5);assert.equal(new Set(values.map(x=>x.cleared)).size,5);
  assert.equal(getRematchNoticeCopy('unknown'),values[0]);
});
const read=name=>readFileSync(new URL('../src/'+name,import.meta.url),'utf8');
test('actual engine readiness rejects deferred round, cached/disconnected state and errors',()=>{
  const e=read('wizardChessEngine.js');const start=e.indexOf('    function getOnlineState()'), end=e.indexOf('    function broadcastOnlineState()',start);assert.ok(start>=0&&end>start);
  const room=view(2,'b').room;
  const ctx={gameMode:'multi',onlineClient:{code:CODE,side:'w',status:'connected',room},onlineRoomSnapshot:room,onlineError:null,onlineEntryPending:false,onlineSessionEpoch:4,onlineVerified:{round:1}};
  runInNewContext(e.slice(start,end),ctx);assert.equal(ctx.getOnlineState().rematchReady,true);
  ctx.onlineClient.room={...room,round:2};assert.equal(ctx.getOnlineState().rematchReady,false);
  ctx.onlineClient.room=room;ctx.onlineClient.status='connecting';assert.equal(ctx.getOnlineState().rematchReady,false);
  ctx.onlineClient.status='connected';ctx.onlineError='invalid';assert.equal(ctx.getOnlineState().rematchReady,false);
  ctx.onlineError=null;ctx.onlineEntryPending=true;assert.equal(ctx.getOnlineState().rematchReady,false);
  ctx.onlineEntryPending=false;ctx.gameMode='single';assert.equal(ctx.getOnlineState().rematchReady,false);
});
test('App subscribes outside panel, reads current engine state and opens existing panel; actions remain server-authorized',()=>{
  const app=read('App.tsx'),panel=read('OnlineMultiplayerPanel.tsx');
  assert.match(app,/rematchTracker\.current\.observe\(chessApi\(\)\?\.getOnlineState\?\.\(\)\)/);
  assert.match(app,/window\.addEventListener\('wizard-chess-online-changed', sync\)/);
  assert.match(app,/noticeMatchesView\(rematchNotice, chessApi\(\)\?\.getOnlineState\?\.\(\)\)/);
  assert.match(app,/openedRematchNotice\.current = rematchNotice\.id;[\s\S]*?setOnlinePanelOpen\(true\)/);
  assert.match(app,/onlinePanelOpen && <OnlineMultiplayerPanel[^>]+rematchNotice=\{rematchNotice\}/);
  assert.match(panel,/incomingRematch && <p[^>]+>\{noticeCopy\.incoming\}/);
  assert.match(panel,/matchingNotice && rematchNotice\?\.kind === 'offer-cleared'/);
  assert.match(panel,/disabled=\{pending \|\| !liveRematch\}[\s\S]*?onlineAction\?\.\('rematch-response',\{accept:true\}\)/);
  assert.match(panel,/disabled=\{pending \|\| !liveRematch\}[\s\S]*?onlineAction\?\.\('rematch-response',\{accept:false\}\)/);
  assert.match(panel,/if \(e\.key === 'Escape'\)/);
});

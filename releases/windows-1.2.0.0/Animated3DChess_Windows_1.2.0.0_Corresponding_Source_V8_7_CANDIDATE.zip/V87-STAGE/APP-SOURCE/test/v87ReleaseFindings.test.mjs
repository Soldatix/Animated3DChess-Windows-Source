import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const read = p=>readFileSync(new URL('../'+p,import.meta.url),'utf8');
test('V87 desktop Info uses fixed official privacy route in frontend and Rust allowlist',()=>{
 const i=read('src/InfoPanel.tsx'), r=read('src-tauri/src/lib.rs');
 const url='https://appsandgames.org/privacy-policy#animated-3d-chess';
 assert.ok(i.includes('href="'+url+'"')); assert.ok(r.includes('"privacy" => "'+url+'"'));
 assert.match(i,/isDesktop && <a href=/); assert.match(i,/openOfficialLink\(event, 'privacy'\)/);
 assert.match(i,/DESKTOP_PRIVACY\[language\]\.description/);
 assert.match(r,/_ => return Err\("Unsupported external link"/);
});
test('V87 desktop privacy copy includes all five locales',()=>{
 const i=read('src/InfoPanel.tsx');
 const text=i.split('const DESKTOP_PRIVACY:')[1].split('const EXTERNAL_LINK_ERROR:')[0];
 for(const l of ['en','hr','de','it','es']) assert.ok(text.includes('"'+l+'":'));
 for(const label of ['Privacy Policy','Pravila privatnosti','Datenschutzerklärung','Informativa sulla privacy','Política de privacidad']) assert.ok(text.includes(label));
});
test('V87 active draw response and resign require connected state and localize not-connected',()=>{
 const p=read('src/OnlineMultiplayerPanel.tsx');
 assert.match(p,/disabled=\{pending \|\| view.connection!=='connected'\} onClick=\{\(\)=>void run\(\(\)=>api\(\)\?\.onlineAction\?\.\('draw-response',\{accept:true\}\)\)\}/);
 assert.match(p,/disabled=\{pending \|\| view.connection!=='connected'\} onClick=\{\(\)=>void run\(\(\)=>api\(\)\?\.onlineAction\?\.\('draw-response',\{accept:false\}\)\)\}/);
 assert.match(p,/disabled=\{pending \|\| view.connection!=='connected'\} onClick=\{\(\)=>\{\s*if\(window.confirm\(w.confirmResign\)\)/);
 assert.match(p,/==='not-connected' \? w.disconnected/);
});

import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {runInNewContext} from 'node:vm';
import {describeOnlineNonMateFinish} from '../src/onlineFinishPresentation.mjs';
import {t, LANGUAGE_CODES} from '../src/i18n.js';
const read = name => readFileSync(new URL('../src/'+name,import.meta.url),'utf8');
const app=read('App.tsx'), engine=read('wizardChessEngine.js'), panel=read('OnlineMultiplayerPanel.tsx');
const section=(a,b)=>{const i=engine.indexOf(a),j=engine.indexOf(b,i+1);assert.ok(i>=0&&j>i);return engine.slice(i,j);};
const actions=app.slice(app.indexOf('<div className="checkmate-actions">'));
test('online end controls are mutually exclusive with offline controls and open existing panel',()=>{
  assert.match(actions,/id="btn-checkmate-undo"[^>]*style=\{\{display:onlineMode\?'none':undefined\}\}/s);
  assert.match(actions,/id="btn-checkmate-newgame"[^>]*style=\{\{display:onlineMode\?'none':undefined\}\}/s);
  assert.match(actions,/id="btn-checkmate-rematch"[^>]*style=\{\{display:onlineMode\?undefined:'none'\}\}\s*onClick=\{\(\)=>setOnlinePanelOpen\(true\)\}/s);
  assert.match(app,/onlinePanelOpen && <OnlineMultiplayerPanel/);
  assert.match(app,/setOnlineMode\(api\?\.getGameMode\?\.\(\) === 'multi'\)/);
  assert.match(panel,/onlineAction\?\.\('rematch-offer'\)/);
  assert.match(panel,/onlineAction\?\.\('rematch-response',\{accept:true\}\)/);
  assert.match(panel,/onlineAction\?\.\('rematch-response',\{accept:false\}\)/);
});
function harness(){
  const dom=new Map(); const el=id=>{if(!dom.has(id)){const classes=new Set();dom.set(id,{dataset:{},textContent:'',classList:{add:x=>classes.add(x),remove:x=>classes.delete(x),contains:x=>classes.has(x)}});}return dom.get(id);};
  const ctx={gameMode:'multi',onlineClient:{code:'ABCDEFGH23',side:'w'},onlineError:null,onlineRoomSnapshot:null,onlineActiveRound:1,onlineAppliedMoves:[],onlineAppliedPly:0,onlineVerified:null,onlineDrainTimer:null,onlineNonMateFinish:null,onlineNonMateVisible:false,checkmateState:{active:false,bannerVisible:false},gameOver:false,isAnimatingMove:false,activeMoveTweens:[],preMoveHighlightTask:null,playerColor:'w',resets:0,broadcastOnlineState(){},freezeOnline(reason){ctx.onlineError=reason;},validateOnlineSnapshot:r=>({round:r.round||1,ply:r.ply,steps:[],fens:[]}),assertOnlinePrefix(){},clearTimeout(){},setTimeout(){return 1;},describeOnlineNonMateFinish,t:k=>t(k,'en'),document:{getElementById:el},resetChessBoard(){ctx.resets++;ctx.clearCheckmateSequence();ctx.gameOver=false;}};
  runInNewContext(section('    function clearCheckmateSequence()','    function captureBoardSnapshot()')+section('    function renderOnlineNonMateFinish()','    function showCheckmateBanner(')+section('    function queueOnlineRoomState(room)','    async function submitOnlineMove('),ctx);
  const room=(revision,round=1,status='finished',result={type:'resignation',winner:'w'},rematchOfferedBy=null)=>({code:'ABCDEFGH23',revision,round,status,result,rematchOfferedBy,ply:0});
  return {ctx,room,el};
}
for(const type of ['resignation','draw-agreed','draw-claimed','draw-automatic']) test(`confirmed ${type} presents result, not king fall`,()=>{
 const {ctx,room,el}=harness();ctx.queueOnlineRoomState(room(1,1,'finished',{type,winner:type==='resignation'?'w':null}));
 assert.equal(ctx.gameOver,true);assert.equal(ctx.resets,0);assert.equal(el('checkmate-overlay').dataset.onlineNonMate,'true');assert.equal(el('checkmate-overlay').classList.contains('visible'),true);assert.equal(el('checkmate-title').textContent,type==='resignation'?'Resignation':'Draw');
 assert.match(read('styles.css'),/data-online-non-mate="true"\] #btn-checkmate-replay\s*\{\s*display: none/);
});
test('checkmate uses existing animation and does not show nonmate banner',()=>{const {ctx,room,el}=harness();ctx.checkmateState.active=true;ctx.queueOnlineRoomState(room(1,1,'finished',{type:'checkmate',winner:'w'}));assert.equal(ctx.gameOver,true);assert.equal(ctx.onlineNonMateFinish,null);assert.equal(el('checkmate-overlay').dataset.onlineNonMate,undefined);});
test('offer, rejection, duplicate and stale snapshots do not reset or reopen dismissed result; accepted round resets once and rotates',()=>{
 const {ctx,room,el}=harness();ctx.queueOnlineRoomState(room(1));ctx.onlineNonMateVisible=false;el('checkmate-overlay').classList.remove('visible');ctx.queueOnlineRoomState(room(2,1,'finished',undefined,'w'));ctx.queueOnlineRoomState(room(3));ctx.queueOnlineRoomState(room(2));assert.equal(ctx.resets,0);assert.equal(el('checkmate-overlay').classList.contains('visible'),false);
 ctx.onlineClient.side='b';ctx.queueOnlineRoomState(room(4,2,'playing',null));assert.equal(ctx.resets,1);assert.equal(ctx.playerColor,'b');assert.equal(ctx.gameOver,false);assert.equal(ctx.onlineRoomSnapshot.code,'ABCDEFGH23');assert.equal(el('checkmate-overlay').dataset.onlineNonMate,undefined);ctx.queueOnlineRoomState(room(4,2,'playing',null));assert.equal(ctx.resets,1);
 ctx.queueOnlineRoomState(room(5,2));assert.equal(el('checkmate-overlay').classList.contains('visible'),true);ctx.onlineClient.side='w';ctx.queueOnlineRoomState(room(6,3,'playing',null));assert.equal(ctx.resets,2);assert.equal(ctx.playerColor,'w');
});
test('all five result translations resolve and unrecognized result is generic',()=>{for(const lang of LANGUAGE_CODES){const tr=k=>t(k,lang);for(const key of ['onlineGameFinished','onlineResignation','onlineDraw'])assert.notEqual(tr(key),key);assert.equal(describeOnlineNonMateFinish({type:'draw-agreed'},tr).subtitle,'½ – ½');assert.equal(describeOnlineNonMateFinish({type:'unexpected'},tr).title,tr('onlineGameFinished'));}});
test('existing local reset and undo guards preserved; replay cannot trigger nonmate animation',()=>{assert.match(engine,/btn-checkmate-newgame'\)\?\.addEventListener\('click', \(\) => \{\s*if \(gameMode !== 'multi'\) resetChessBoard/);assert.match(engine,/function undoLastTurn\(\) \{\s*if \(\(gameMode !== 'single' && gameMode !== 'local'\)/);assert.match(engine,/btn-checkmate-replay'\)\?\.addEventListener\('click', \(\) => \{\s*if \(onlineNonMateFinish\) return/);});

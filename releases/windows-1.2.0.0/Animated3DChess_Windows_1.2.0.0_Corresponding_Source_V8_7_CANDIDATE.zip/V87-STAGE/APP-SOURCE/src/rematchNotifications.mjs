// Windows V8.6: presentation only. Never send a request or reset a board.
// Only consume the engine's current, validated, connected room snapshot.
const sideOk = side => side === 'w' || side === 'b';
export function createRematchNotifications() {
  let previous = null, notice = null, sequence = 0;
  const clear = () => { previous = null; notice = null; };
  return {
    observe(view) {
      const room = view?.room;
      if (!view?.code || !sideOk(view.side) || view.connection === 'expired' || view.error) {
        clear(); return null;
      }
      if (previous && (previous.code !== view.code || previous.epoch !== view.sessionEpoch)) clear();
      // A reconnect can publish cached state before an authenticated snapshot.
      // Keep the last confirmed transition, but do not display cached notices.
      if (view.rematchReady !== true || view.connection !== 'connected' || !room || room.code !== view.code) return null;
      const round = room.round ?? 1;
      if (!Number.isSafeInteger(round) || round < 1 || !Number.isSafeInteger(room.revision) || room.revision < 1) return null;
      const current = {code:view.code, epoch:view.sessionEpoch, side:view.side, round,
        revision:room.revision, status:room.status, offer:room.rematchOfferedBy,
        both:room.whiteJoined === true && room.blackJoined === true};
      if (previous && (round < previous.round || current.revision < previous.revision)) return null;
      if (previous && round === previous.round && current.revision === previous.revision) {
        // Repeated snapshot is not a new notification. Conflicting equal-revision
        // payloads are not evidence of a transition.
        return current.side === previous.side && current.offer === previous.offer && current.status === previous.status && current.both === previous.both ? notice : null;
      }
      const same = previous && previous.round === round && previous.side === current.side;
      if (!same || current.status !== 'finished' || !current.both) notice = null;
      if (current.status === 'finished' && current.both) {
        if (sideOk(current.offer) && current.offer !== current.side) {
          if (!same || previous.offer !== current.offer || previous.status !== 'finished' || !previous.both || !notice) {
            notice = {...current, id:++sequence, kind:'incoming'};
          }
        } else if (current.offer === null && same && previous.status === 'finished' && previous.both && previous.offer === current.side) {
          // Explicit clearing in the same finished round, not acceptance (new
          // round), expiry, an absent legacy field, or a network failure. The
          // protocol has no separately authenticated decline-reason field.
          notice = {...current, id:++sequence, kind:'offer-cleared'};
        } else if (current.offer !== null || notice?.kind !== 'offer-cleared') notice = null;
      }
      previous = current;
      return notice;
    }
  };
}
export function noticeMatchesView(notice, view) {
  const room = view?.room;
  return Boolean(notice && view?.rematchReady === true && view.connection === 'connected' && !view.error && room?.status === 'finished' && room.whiteJoined === true && room.blackJoined === true &&
    notice.code === view.code && room.code === view.code && notice.epoch === view.sessionEpoch && notice.round === (room.round ?? 1) && notice.side === view.side &&
    room.revision >= notice.revision && (notice.kind === 'incoming' ? room.rematchOfferedBy === notice.offer : notice.kind === 'offer-cleared' && room.rematchOfferedBy === null));
}
// A notice can open the existing panel once. A competing modal defers it;
// manually closing the panel does not make duplicate snapshots reopen it.
export function shouldAutoOpenRematch(notice, handledId, blocked) {
  return Boolean(notice && notice.id !== handledId && !blocked);
}
export const rematchNoticeCopy = {
  en:{incoming:'Your opponent has offered a rematch.', cleared:'Your rematch offer was declined or is no longer pending.', open:'Open multiplayer'},
  hr:{incoming:'Protivnik ti je ponudio revanš.', cleared:'Tvoja ponuda za revanš je odbijena ili više nije na čekanju.', open:'Otvori online igru'},
  de:{incoming:'Dein Gegner hat eine Revanche angeboten.', cleared:'Dein Revancheangebot wurde abgelehnt oder ist nicht mehr offen.', open:'Mehrspieler öffnen'},
  it:{incoming:'Il tuo avversario ha offerto una rivincita.', cleared:'La tua offerta di rivincita è stata rifiutata o non è più in sospeso.', open:'Apri multigiocatore'},
  es:{incoming:'Tu rival ha ofrecido una revancha.', cleared:'Tu oferta de revancha ha sido rechazada o ya no está pendiente.', open:'Abrir multijugador'}
};
export function getRematchNoticeCopy(language) { return rematchNoticeCopy[language] ?? rematchNoticeCopy.en; }

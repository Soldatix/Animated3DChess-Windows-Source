// Result presentation only. The server and existing round transition remain authoritative.
export function describeOnlineNonMateFinish(result, t) {
  if (result?.type === 'resignation' && ['w','b'].includes(result.winner)) {
    return {title:t('onlineResignation'), subtitle:`${t(result.winner === 'w' ? 'white' : 'black')} ${t('wins')}`, crown:result.winner === 'w' ? '♔' : '♚'};
  }
  if (['draw-agreed','draw-automatic','draw-claimed'].includes(result?.type)) {
    return {title:t('onlineDraw'), subtitle:'½ – ½', crown:'½'};
  }
  return {title:t('onlineGameFinished'), subtitle:'', crown:'♔'};
}

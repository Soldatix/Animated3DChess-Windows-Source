# Windows 1.2.0.0 — corresponding source review candidate

Requirements: Windows 11, Node 24.x, npm 11.x, Rust/Tauri toolchain and Windows SDK.
From APP-SOURCE, run: `npm ci`, then `node --test test/*.test.mjs` (shell glob handling differs;
the QA runner enumerates all test/*.test.mjs), `npm run lint`, `npm run build:windows`, then
`npm run tauri -- build --config src-tauri/tauri.p3c-prod.conf.json --config src-tauri/Production-Only-Tauri-Override.json --no-bundle --ci`.
For MSIX: use `AppxManifest.xml`, copy app.exe, `WINDOWS-PACKAGING-INPUTS/Assets/*`, and `Legal/*`
into one payload directory. Run Windows SDK `makeappx.exe pack /d <payload> /p <output.msix>`.
The four included PNG icons are the exact images from this review package.
The historical test-only multiplayer-server/src/game.mjs is NOT the deployed V1.2 Worker.
The production service revision must be documented separately.
Builds are not claimed byte-for-byte reproducible.
Reference V8 EXE SHA-256: 1f7cfe07fca7d8d55eb20ad38dd031c212875749b72422f66c64ffbf7aef5da9

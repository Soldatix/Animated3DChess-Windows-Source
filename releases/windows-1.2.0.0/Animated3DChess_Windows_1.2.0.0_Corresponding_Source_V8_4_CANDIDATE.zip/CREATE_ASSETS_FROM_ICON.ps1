param(
    [Parameter(Mandatory=$true)][string]$IconPath,
    [Parameter(Mandatory=$true)][string]$OutputDirectory
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
$dimensions = @(
    @{Name='StoreLogo.png'; W=50; H=50},
    @{Name='AppList.png';   W=44; H=44},
    @{Name='MedTile.png';   W=150; H=150},
    @{Name='WideTile.png';  W=310; H=150}
)
New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
$image = [System.Drawing.Image]::FromFile($IconPath)
try {
    foreach ($item in $dimensions) {
        $bmp = New-Object System.Drawing.Bitmap -ArgumentList @([int]$item.W, [int]$item.H)
        try {
            $graphics = [System.Drawing.Graphics]::FromImage($bmp)
            try {
                $graphics.Clear([System.Drawing.Color]::Transparent)
                $graphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
                $graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
                $graphics.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
                $scale = [Math]::Min(([double]$item.W / $image.Width), ([double]$item.H / $image.Height))
                $width = [Math]::Max(1, [int][Math]::Round($image.Width * $scale))
                $height = [Math]::Max(1, [int][Math]::Round($image.Height * $scale))
                $left = [int][Math]::Floor(($item.W - $width) / 2)
                $top = [int][Math]::Floor(($item.H - $height) / 2)
                $graphics.DrawImage($image, $left, $top, $width, $height)
            } finally {
                $graphics.Dispose()
            }
            $bmp.Save((Join-Path $OutputDirectory $item.Name), [System.Drawing.Imaging.ImageFormat]::Png)
        } finally {
            $bmp.Dispose()
        }
    }
} finally {
    $image.Dispose()
}
Write-Output 'ASSETS_FROM_ORIGINAL_ICON=PASS'

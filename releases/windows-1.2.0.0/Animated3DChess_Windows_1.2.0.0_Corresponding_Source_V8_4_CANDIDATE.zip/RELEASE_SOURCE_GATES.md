# V1.2 corresponding-source candidate — NOT PUBLISHED

Source and notices require independent audit before distribution.
The StoreContext live test requires a separately authorized private Store flight.
No Git push or Store distribution was performed in this review.
The six 3D model files and four MSIX icons are preserved according to user decision;
independent distribution-rights evidence is not claimed by this statement.

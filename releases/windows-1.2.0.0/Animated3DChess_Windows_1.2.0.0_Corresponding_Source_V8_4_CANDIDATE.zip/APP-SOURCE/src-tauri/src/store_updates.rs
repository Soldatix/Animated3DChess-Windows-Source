use serde::Serialize;

// WinRT must be initialized on the thread which makes the StoreContext call.
// This app uses windows 0.62.2, where windows::core::init_mta is unavailable.
// Microsoft documents RoInitialize/RoUninitialize in RuntimeObject.lib.
#[cfg(target_os = "windows")]
#[link(name = "runtimeobject")]
unsafe extern "system" {
    fn RoInitialize(init_type: u32) -> i32;
    fn RoUninitialize();
}

#[cfg(target_os = "windows")]
const RO_INIT_MULTITHREADED: u32 = 1;

// Each successful RoInitialize call, including S_FALSE (already initialized),
// requires a matching RoUninitialize on the same thread.
#[cfg(target_os = "windows")]
struct WinRtApartment;

#[cfg(target_os = "windows")]
impl Drop for WinRtApartment {
    fn drop(&mut self) {
        unsafe { RoUninitialize(); }
    }
}

#[derive(Serialize)]
pub struct StoreUpdateCheck {
    pub status: &'static str,
    pub reason: &'static str,
    pub update_count: u32,
}

fn result(status: &'static str, reason: &'static str, count: u32) -> StoreUpdateCheck {
    StoreUpdateCheck { status, reason, update_count: count }
}

#[cfg(target_os = "windows")]
fn query() -> StoreUpdateCheck {
    use windows::ApplicationModel::Package;
    use windows::Services::Store::StoreContext;

    // Never report 'current' when launched as an ordinary, unpackaged app.exe.
    // StoreContext applies to the identity of THIS PROCESS, not an unrelated
    // Store-installed V1.1 on the same PC.
    let init_hr = unsafe { RoInitialize(RO_INIT_MULTITHREADED) };
    if init_hr < 0 {
        return result("unavailable", "WINDOWS_COM_UNAVAILABLE", 0);
    }
    let _apartment = WinRtApartment;
    let package = match Package::Current() {
        Ok(p) => p,
        Err(_) => return result("unavailable", "NOT_MSIX_PACKAGED", 0),
    };
    let id = match package.Id() {
        Ok(i) => i,
        Err(_) => return result("unavailable", "PACKAGE_ID_UNAVAILABLE", 0),
    };
    let name = match id.Name() {
        Ok(n) => n.to_string(),
        Err(_) => return result("unavailable", "PACKAGE_NAME_UNAVAILABLE", 0),
    };
    if name != "Soldatix.Animated3DChess" {
        return result("unavailable", "UNEXPECTED_PACKAGE_IDENTITY", 0);
    }
    // Match the exact production publisher-derived Package Family Name too.
    match id.FamilyName() {
        Ok(family) if family.to_string() == "Soldatix.Animated3DChess_ghspp2csrexvc" => {}
        _ => return result("unavailable", "UNEXPECTED_PACKAGE_PUBLISHER", 0),
    }
    let context = match StoreContext::GetDefault() {
        Ok(c) => c,
        Err(_) => return result("unavailable", "STORE_CONTEXT_UNAVAILABLE", 0),
    };
    let operation = match context.GetAppAndOptionalStorePackageUpdatesAsync() {
        Ok(o) => o,
        Err(_) => return result("unavailable", "STORE_QUERY_UNAVAILABLE", 0),
    };
    // join() is from windows-future 0.3.2 (windows 0.62.2 dependency).
    // This runs on a dedicated blocking worker, never the WebView UI thread.
    let updates = match operation.join() {
        Ok(u) => u,
        Err(_) => return result("unavailable", "STORE_QUERY_FAILED", 0),
    };
    match updates.Size() {
        Ok(count) if count > 0 => result("available", "", count),
        Ok(_) => result("current", "", 0),
        Err(_) => result("unavailable", "STORE_RESULT_UNAVAILABLE", 0),
    }
}

#[cfg(not(target_os = "windows"))]
fn query() -> StoreUpdateCheck {
    result("unavailable", "NOT_WINDOWS", 0)
}

#[tauri::command]
pub async fn check_store_package_updates() -> StoreUpdateCheck {
    match tauri::async_runtime::spawn_blocking(query).await {
        Ok(status) => status,
        Err(_) => result("unavailable", "STORE_WORKER_FAILED", 0),
    }
}

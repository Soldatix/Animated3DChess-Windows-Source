// P3-B3: Browser fallback for local testing, Windows Credential Manager for Tauri.
// Never write a bearer token to localStorage in the Windows edition.
const CODE = /^[A-HJ-NP-Z2-9]{10}$/;
const TOKEN = /^[A-Za-z0-9_-]{40,80}$/;
const KEY = 'animated3dchess:online-session:v1:';

// Tauri instances in one renderer share a Credential Manager record per server.
// A per-instance queue is insufficient: a late Leave from room A could erase
// room B's newly saved seat. Serialize all native operations for this key.
const nativeQueues = new Map();
function sequenceNative(key, task) {
  const prior = nativeQueues.get(key) ?? Promise.resolve();
  const result = prior.then(task, task);
  const tail = result.then(() => {}, () => {});
  nativeQueues.set(key, tail);
  void tail.then(() => {
    if (nativeQueues.get(key) === tail) nativeQueues.delete(key);
  });
  return result;
}

function storeFor(storage) {
  if (storage !== undefined) return storage;
  try { return globalThis.localStorage ?? null; } catch { return null; }
}
function parseRecord(raw, baseUrl, now) {
  if (typeof raw !== 'string' || raw.length > 1024) return null;
  try {
    const record = JSON.parse(raw);
    // No client-side 48h expiry: the server expires the room by *last activity*,
    // while this timestamp records only the last local checkpoint.
    if (!record || record.v !== 1 || record.baseUrl !== baseUrl ||
        !CODE.test(record.code) || !['w', 'b'].includes(record.side) ||
        !TOKEN.test(record.token) || !Number.isSafeInteger(record.at) ||
        record.at < 0 || record.at > now + 60_000) return null;
    return {code:record.code, side:record.side, token:record.token};
  } catch { return null; }
}
function nativeInvoke() {
  try {
    const core = globalThis.__TAURI__?.core;
    return typeof core?.invoke === 'function' ? (cmd, args) => core.invoke(cmd, args) : null;
  } catch { return null; }
}
export function createOnlineSessionStore({baseUrl, storage, now = () => Date.now(), runtimeMode} = {}) {
  // The production desktop build must NEVER fall back to browser token storage.
  // runtimeMode permits deterministic Node tests; it cannot override a desktop build.
  const desktop = import.meta.env?.MODE === 'desktop' || runtimeMode === 'desktop';
  if (typeof baseUrl !== 'string' || !/^https?:\/\//.test(baseUrl)) throw new Error('invalid-server-url');
  const key = KEY + encodeURIComponent(baseUrl);
  const marker = key + ':forget-pending'; // contains no secret
  const s = storeFor(storage);
  // Explicit injected storage is used by browser tests; never silently route it to native.
  const invoke = storage === undefined ? nativeInvoke() : null;
  // Increment synchronously on Leave, before an earlier native save can resolve.
  // A stale save must not cancel the newer user's "forget this room" intent.
  let leaveEpoch = 0;
  const sequence = task => sequenceNative(key, task);
  const localRead = () => {
    if (!s) return null;
    try { return parseRecord(s.getItem(key), baseUrl, now()); } catch { return null; }
  };
  const localRemove = () => { try { s?.removeItem(key); } catch {} };
  const hasMarker = () => { try { return s?.getItem(marker) === '1'; } catch { return false; } };
  const setMarker = () => { try { s?.setItem(marker, '1'); } catch {} };
  const clearMarker = () => { try { s?.removeItem(marker); } catch {} };
  const serialize = ({code, side, token}) => {
    const record = {v:1, baseUrl, code, side, token, at:now()};
    const raw = JSON.stringify(record);
    return parseRecord(raw, baseUrl, now()) ? raw : null;
  };
  if (!invoke && desktop) {
    // Fail closed if the desktop Tauri bridge is missing. Browser fallback is
    // deliberately unavailable here, including when a storage object is injected.
    const bridgeUnavailable = () => new Error('secure-session-bridge-unavailable');
    return {
      requiresAsyncLookup: true,
      load() { return null; },
      async loadAsync() { throw bridgeUnavailable(); },
      save() { return false; },
      async saveAsync() { throw bridgeUnavailable(); },
      clear() { setMarker(); localRemove(); },
      async clearAsync() { setMarker(); localRemove(); throw bridgeUnavailable(); },
    };
  }
  if (!invoke) {
    return {
      requiresAsyncLookup: false,
      load() {
        const record = localRead();
        if (!record) localRemove();
        return record;
      },
      async loadAsync() { return this.load(); },
      save(input) {
        if (!s) return false;
        const raw = serialize(input);
        if (!raw) return false;
        try { s.setItem(key, raw); return true; } catch { return false; }
      },
      async saveAsync(input) { return this.save(input); },
      clear() { localRemove(); },
      async clearAsync() { this.clear(); return true; },
    };
  }
  // Native calls are serialized to avoid a slow save racing an explicit Leave.
  const loadAsync = () => sequence(async () => {
    if (hasMarker()) {
      const seenEpoch = leaveEpoch;
      try {
        await invoke('online_vault_clear', {baseUrl});
        // Keep a newer Leave marker even if an earlier cleanup just completed.
        if (seenEpoch === leaveEpoch) clearMarker();
      } catch { /* Retain the tombstone and retry on the next launch. */ }
      return null;
    }
    const raw = await invoke('online_vault_load', {baseUrl});
    const saved = parseRecord(raw, baseUrl, now());
    if (saved) {
      localRemove(); // clean any previous plaintext checkpoint
      return saved;
    }
    if (raw) throw new Error('secure-session-invalid'); // never silently discard the vault
    const legacy = localRead();
    if (!legacy) { localRemove(); return null; }
    const migratedRaw = serialize(legacy);
    if (!migratedRaw) return null;
    // Move the existing seat before deleting the old browser checkpoint.
    await invoke('online_vault_save', {baseUrl, record:migratedRaw});
    localRemove();
    return legacy;
  });
  const saveAsync = input => {
    const seenEpoch = leaveEpoch;
    return sequence(async () => {
      const raw = serialize(input);
      if (!raw) return false;
      await invoke('online_vault_save', {baseUrl, record:raw});
      localRemove(); // delete legacy plaintext only after confirmed native persistence
      // Never clear a tombstone written by a newer explicit Leave.
      if (seenEpoch === leaveEpoch) clearMarker();
      return true;
    });
  };
  const clearAsync = () => {
    // Tombstone must be synchronous so rapid app shutdown never restores a left seat.
    const seenEpoch = ++leaveEpoch;
    setMarker();
    localRemove();
    return sequence(async () => {
      await invoke('online_vault_clear', {baseUrl});
      if (seenEpoch === leaveEpoch) clearMarker();
      return true;
    });
  };
  return {
    requiresAsyncLookup: true,
    load() { return null; }, // native reads must be awaited
    loadAsync,
    save() { return false; }, // never fall back to plaintext in Tauri
    saveAsync,
    clear() { void clearAsync().catch(() => {}); },
    clearAsync,
  };
}

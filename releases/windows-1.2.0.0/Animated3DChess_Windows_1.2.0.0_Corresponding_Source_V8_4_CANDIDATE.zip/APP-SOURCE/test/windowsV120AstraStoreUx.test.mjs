import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {fileURLToPath,pathToFileURL} from 'node:url';
import path from 'node:path';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
let serial=0;
async function loadUpdateManager(invoker){
  globalThis.localStorage={getItem:()=>null,setItem:()=>{},removeItem:()=>{}};
  globalThis.window={
    setTimeout:()=>1,clearTimeout:()=>{},setInterval:()=>1,
    matchMedia:()=>({matches:false}),
    wizardChess:{getGameMode:()=> 'computer'},
    __TAURI__:{core:{invoke:invoker}}
  };
  Object.defineProperty(globalThis,'navigator',{configurable:true,value:{standalone:false}});
  const source=readFileSync(path.join(root,'src/updateManager.mjs'),'utf8')
    .replace("from './updateManagerCore.mjs'", `from '${pathToFileURL(path.join(root,'src/updateManagerCore.mjs')).href}'`)
    .replaceAll('import.meta.env.MODE',"'desktop'")
    .replaceAll('__CHESS_APP_VERSION__',"'1.2.0'");
  return import(`data:text/javascript;charset=utf-8,${encodeURIComponent(source)}#${serial++}`);
}

test('Astra: a successful Store launch preserves the previous unpackaged status',async()=>{
  const invoked=[];
  const u=await loadUpdateManager(async(name,args)=>{
    invoked.push([name,args]);
    if(name==='check_store_package_updates')return {status:'unavailable',reason:'NOT_MSIX_PACKAGED'};
  });
  await u.checkForUpdates({manual:true});
  assert.equal(u.getUpdateSnapshot().message,'STORE_REQUIRES_MSIX');
  assert.equal(await u.openMicrosoftStore(),true);
  assert.equal(u.getUpdateSnapshot().message,'STORE_REQUIRES_MSIX');
  assert.deepEqual(invoked.at(-1)[1],{kind:'store-app'});
});

test('Astra: Store URI failure followed by HTTPS fallback does not erase check status',async()=>{
  const calls=[];
  const u=await loadUpdateManager(async(name,args)=>{
    calls.push(args?.kind ?? name);
    if(name==='check_store_package_updates')return {status:'unavailable',reason:'NOT_MSIX_PACKAGED'};
    if(args?.kind==='store-app')throw Error('URI disabled');
  });
  await u.checkForUpdates({manual:true});
  assert.equal(await u.openMicrosoftStore(),true);
  assert.equal(u.getUpdateSnapshot().message,'STORE_REQUIRES_MSIX');
  assert.deepEqual(calls.slice(-2),['store-app','store']);
});

test('Astra: two failing Store navigation methods produce a distinct navigation error',async()=>{
  const u=await loadUpdateManager(async(name,args)=>{
    if(name==='check_store_package_updates')return {status:'unavailable',reason:'NOT_MSIX_PACKAGED'};
    throw Error('unable to open');
  });
  await u.checkForUpdates({manual:true});
  assert.equal(await u.openMicrosoftStore(),false);
  assert.equal(u.getUpdateSnapshot().message,'STORE_OPEN_FAILED');
  assert.notEqual(u.getUpdateSnapshot().status,'current');
});

test('Astra: all five languages distinguish failed Store navigation from failed update check',async()=>{
  const copy=await import(pathToFileURL(path.join(root,'src/updateCopy.mjs')).href);
  for(const locale of ['en','hr','de','it','es']){
    const item=copy.updateCopy(locale);
    assert.equal(typeof item.storeOpenFailed,'string');
    assert.ok(item.storeOpenFailed.length>35);
    assert.notEqual(item.storeOpenFailed,item.failed);
  }
  const info=readFileSync(path.join(root,'src/InfoPanel.tsx'),'utf8');
  assert.match(info,/STORE_OPEN_FAILED'\s*\?\s*ux\.storeOpenFailed/);
});

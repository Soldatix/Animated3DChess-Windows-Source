import test from 'node:test';
import assert from 'node:assert/strict';
import {createOnlineSessionStore} from '../src/onlineMultiplayerSessionStore.mjs';

const BASE='https://chess-multiplayer-v11-prod.soldatix.workers.dev';
const SEAT_A={code:'ABCDEFGH23',side:'w',token:'A'.repeat(43)};
const SEAT_B={code:'HGFEDCBA23',side:'b',token:'B'.repeat(43)};
function gate(){let resolve; const promise=new Promise(r=>resolve=r);return {promise,resolve};}
function fakeStorage(){const map=new Map();return {map,getItem:k=>map.get(k)??null,setItem:(k,v)=>map.set(k,v),removeItem:k=>map.delete(k)};}
async function inNativeEnvironment(fn){
  const beforeTauri=globalThis.__TAURI__,beforeStorage=globalThis.localStorage;
  const storage=fakeStorage();globalThis.localStorage=storage;
  try{await fn(storage);} finally {
    if(beforeTauri===undefined)delete globalThis.__TAURI__;else globalThis.__TAURI__=beforeTauri;
    if(beforeStorage===undefined)delete globalThis.localStorage;else globalThis.localStorage=beforeStorage;
  }
}

test('Astra follow-up: Leave A delayed native clear cannot remove room B saved by a second store instance',async()=>inNativeEnvironment(async(storage)=>{
  const vault=new Map(),started=gate(),release=gate(),order=[];
  globalThis.__TAURI__={core:{invoke:async(cmd,{baseUrl,record})=>{
    if(cmd==='online_vault_save'){order.push('save:'+JSON.parse(record).code);vault.set(baseUrl,record);return null;}
    if(cmd==='online_vault_clear'){order.push('clear:start');started.resolve();await release.promise;vault.delete(baseUrl);order.push('clear:end');return null;}
    if(cmd==='online_vault_load')return vault.get(baseUrl)??null;
    throw new Error('Unexpected vault command');
  }}};
  const a=createOnlineSessionStore({baseUrl:BASE,runtimeMode:'desktop'});
  assert.equal(await a.saveAsync(SEAT_A),true);
  a.clear(); // intentionally not awaited: this matches the real online client's close({forget:true})
  await started.promise;
  const b=createOnlineSessionStore({baseUrl:BASE,runtimeMode:'desktop'});
  const savingB=b.saveAsync(SEAT_B);
  assert.equal(JSON.parse(vault.get(BASE)).code,SEAT_A.code);
  release.resolve();
  assert.equal(await savingB,true);
  assert.deepEqual(order,['save:'+SEAT_A.code,'clear:start','clear:end','save:'+SEAT_B.code]);
  assert.deepEqual(await b.loadAsync(),SEAT_B);
  assert.equal([...storage.map.keys()].some(k=>k.endsWith(':forget-pending')),false);
  assert.equal([...storage.map.values()].some(v=>v.includes(SEAT_B.token)),false);
}));

test('Astra follow-up: a slow old save, Leave and immediate new Join preserve the new seat',async()=>inNativeEnvironment(async()=>{
  const vault=new Map(),oldStarted=gate(),releaseOld=gate(),operations=[];
  globalThis.__TAURI__={core:{invoke:async(cmd,{baseUrl,record})=>{
    if(cmd==='online_vault_save'){
      const data=JSON.parse(record);
      operations.push('save:'+data.code);
      if(data.code===SEAT_A.code){oldStarted.resolve();await releaseOld.promise;}
      vault.set(baseUrl,record);return null;
    }
    if(cmd==='online_vault_clear'){operations.push('clear');vault.delete(baseUrl);return null;}
    if(cmd==='online_vault_load')return vault.get(baseUrl)??null;
    throw new Error('Unexpected vault command');
  }}};
  const a=createOnlineSessionStore({baseUrl:BASE,runtimeMode:'desktop'});
  const oldSave=a.saveAsync(SEAT_A);
  await oldStarted.promise;
  a.clear();
  const b=createOnlineSessionStore({baseUrl:BASE,runtimeMode:'desktop'});
  const newSave=b.saveAsync(SEAT_B);
  releaseOld.resolve();
  assert.equal(await oldSave,true);
  assert.equal(await newSave,true);
  assert.deepEqual(operations,['save:'+SEAT_A.code,'clear','save:'+SEAT_B.code]);
  assert.deepEqual(await b.loadAsync(),SEAT_B);
}));

test('Astra follow-up: failed old delete does not prevent a subsequent successful room B save',async()=>inNativeEnvironment(async(storage)=>{
  const vault=new Map();let clears=0;
  globalThis.__TAURI__={core:{invoke:async(cmd,{baseUrl,record})=>{
    if(cmd==='online_vault_save'){vault.set(baseUrl,record);return null;}
    if(cmd==='online_vault_clear'){clears++;if(clears===1)throw Error('temporary native failure');vault.delete(baseUrl);return null;}
    if(cmd==='online_vault_load')return vault.get(baseUrl)??null;
    throw Error('Unexpected command');
  }}};
  const a=createOnlineSessionStore({baseUrl:BASE,runtimeMode:'desktop'});
  await a.saveAsync(SEAT_A);
  await assert.rejects(a.clearAsync(),/temporary native failure/);
  assert.equal([...storage.map.keys()].some(k=>k.endsWith(':forget-pending')),true);
  const b=createOnlineSessionStore({baseUrl:BASE,runtimeMode:'desktop'});
  assert.equal(await b.saveAsync(SEAT_B),true);
  assert.equal([...storage.map.keys()].some(k=>k.endsWith(':forget-pending')),false);
  assert.deepEqual(await b.loadAsync(),SEAT_B);
}));

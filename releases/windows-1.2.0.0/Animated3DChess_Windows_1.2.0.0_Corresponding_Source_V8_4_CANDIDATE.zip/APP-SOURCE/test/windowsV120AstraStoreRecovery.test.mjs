import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {fileURLToPath,pathToFileURL} from 'node:url';
import path from 'node:path';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
let count=0;
async function loadUpdateManager(invoke){
  globalThis.localStorage={getItem:()=>null,setItem:()=>{},removeItem:()=>{}};
  globalThis.window={setTimeout:()=>1,clearTimeout:()=>{},setInterval:()=>1,matchMedia:()=>({matches:false}),
    wizardChess:{getGameMode:()=> 'computer'},__TAURI__:{core:{invoke}}};
  Object.defineProperty(globalThis,'navigator',{configurable:true,value:{standalone:false}});
  const source=readFileSync(path.join(root,'src/updateManager.mjs'),'utf8')
    .replace("from './updateManagerCore.mjs'",`from '${pathToFileURL(path.join(root,'src/updateManagerCore.mjs')).href}'`)
    .replaceAll('import.meta.env.MODE',"'desktop'")
    .replaceAll('__CHESS_APP_VERSION__',"'1.2.0'");
  return import(`data:text/javascript;charset=utf-8,${encodeURIComponent(source)}#${count++}`);
}

test('Store updater retains unpackaged verdict after failed and then successful navigation',async()=>{
  let failNavigation=true;
  const u=await loadUpdateManager(async(cmd)=>{
    if(cmd==='check_store_package_updates')return {status:'unavailable',reason:'NOT_MSIX_PACKAGED'};
    if(failNavigation)throw Error('browser launch blocked');
    return null;
  });
  await u.checkForUpdates({manual:true});
  assert.equal(u.getUpdateSnapshot().message,'STORE_REQUIRES_MSIX');
  assert.equal(await u.openMicrosoftStore(),false);
  assert.equal(u.getUpdateSnapshot().message,'STORE_OPEN_FAILED');
  failNavigation=false;
  assert.equal(await u.openMicrosoftStore(),true);
  assert.equal(u.getUpdateSnapshot().message,'STORE_REQUIRES_MSIX');
  assert.equal(u.getUpdateSnapshot().status,'unknown');
});

test('Store updater retains unavailable-service verdict after failed and then successful navigation',async()=>{
  let failNavigation=true;
  const u=await loadUpdateManager(async(cmd)=>{
    if(cmd==='check_store_package_updates')return {status:'unavailable',reason:'STORE_SERVICE_FAILURE'};
    if(failNavigation)throw Error('failed to open');
    return null;
  });
  await u.checkForUpdates({manual:true});
  assert.equal(u.getUpdateSnapshot().message,'STORE_CHECK_UNAVAILABLE');
  assert.equal(await u.openMicrosoftStore(),false);
  failNavigation=false;
  assert.equal(await u.openMicrosoftStore(),true);
  assert.equal(u.getUpdateSnapshot().message,'STORE_CHECK_UNAVAILABLE');
});

test('Store updater preserves failed check error after recovery of navigation',async()=>{
  let failNavigation=true;
  const u=await loadUpdateManager(async(cmd)=>{
    if(cmd==='check_store_package_updates')throw Error('offline');
    if(failNavigation)throw Error('failed to open');
    return null;
  });
  await u.checkForUpdates({manual:true});
  assert.equal(u.getUpdateSnapshot().message,'CHECK_FAILED');
  assert.equal(await u.openMicrosoftStore(),false);
  failNavigation=false;
  assert.equal(await u.openMicrosoftStore(),true);
  assert.equal(u.getUpdateSnapshot().message,'CHECK_FAILED');
});

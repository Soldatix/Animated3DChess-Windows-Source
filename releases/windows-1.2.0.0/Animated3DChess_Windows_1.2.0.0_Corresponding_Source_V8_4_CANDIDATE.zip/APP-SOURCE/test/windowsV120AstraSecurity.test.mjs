import test from 'node:test';
import assert from 'node:assert/strict';
import { createOnlineSessionStore } from '../src/onlineMultiplayerSessionStore.mjs';

const BASE = 'https://chess-multiplayer-v11-prod.soldatix.workers.dev';
const CODE = 'ABCDEFGH23';
const TOKEN = 'S'.repeat(43);
const seat = {code:CODE,side:'w',token:TOKEN};
const delay = () => { let resolve; const promise=new Promise(r=>{resolve=r}); return {promise,resolve}; };
function storage(){
  const map=new Map();
  return {map,getItem:k=>map.get(k)??null,setItem:(k,v)=>map.set(k,v),removeItem:k=>map.delete(k)};
}
function withEnvironment(fn){
  const previous=globalThis.localStorage, previousTauri=globalThis.__TAURI__;
  const s=storage();globalThis.localStorage=s;
  const restore=()=>{
    if(previous===undefined)delete globalThis.localStorage;else globalThis.localStorage=previous;
    if(previousTauri===undefined)delete globalThis.__TAURI__;else globalThis.__TAURI__=previousTauri;
  };
  return Promise.resolve().then(()=>fn(s)).finally(restore);
}

test('Astra: desktop without Tauri bridge refuses all plaintext token persistence',async()=>withEnvironment(async s=>{
  delete globalThis.__TAURI__;
  const nativeExpected=createOnlineSessionStore({baseUrl:BASE,runtimeMode:'desktop'});
  assert.equal(nativeExpected.requiresAsyncLookup,true);
  assert.equal(nativeExpected.save(seat),false);
  await assert.rejects(nativeExpected.saveAsync(seat),/secure-session-bridge-unavailable/);
  await assert.rejects(nativeExpected.loadAsync(),/secure-session-bridge-unavailable/);
  // Explicit injected storage must not override a desktop runtime.
  const injected=createOnlineSessionStore({baseUrl:BASE,storage:s,runtimeMode:'desktop'});
  assert.equal(injected.save(seat),false);
  await assert.rejects(injected.saveAsync(seat),/secure-session-bridge-unavailable/);
  assert.equal([...s.map.values()].some(value=>value.includes(TOKEN)),false);
}));

test('Astra: old slow save cannot remove a new Leave marker when native delete fails',async()=>withEnvironment(async s=>{
  const slow=delay(),started=delay();let deleteFails=true;
  const vault=new Map();
  globalThis.__TAURI__={core:{invoke:async(name,args)=>{
    if(name==='online_vault_save'){
      started.resolve();await slow.promise;vault.set(args.baseUrl,args.record);return null;
    }
    if(name==='online_vault_clear'){
      if(deleteFails)throw Error('temporary native clear failure');
      vault.delete(args.baseUrl);return null;
    }
    if(name==='online_vault_load')return vault.get(args.baseUrl)??null;
    throw Error('Unexpected invoke command: '+name);
  }}};
  const store=createOnlineSessionStore({baseUrl:BASE,runtimeMode:'desktop'});
  const saving=store.saveAsync(seat);
  await started.promise;
  const leaving=store.clearAsync();
  assert.equal([...s.map.entries()].some(([key,value])=>key.endsWith(':forget-pending')&&value==='1'),true);
  slow.resolve();
  assert.equal(await saving,true);
  await assert.rejects(leaving,/temporary native clear failure/);
  assert.equal(vault.size,1,'failed delete leaves a native record, which must remain tombstoned');
  assert.equal([...s.map.entries()].some(([key,value])=>key.endsWith(':forget-pending')&&value==='1'),true,'Leave marker must survive an older save');
  assert.equal([...s.map.values()].some(value=>value.includes(TOKEN)),false,'marker is nonsecret');
  deleteFails=false;
  const reopened=createOnlineSessionStore({baseUrl:BASE,runtimeMode:'desktop'});
  assert.equal(await reopened.loadAsync(),null,'must not resurrect explicitly left room');
  assert.equal(vault.size,0,'retry must actually remove native vault record');
  assert.equal([...s.map.entries()].some(([key])=>key.endsWith(':forget-pending')),false,'confirmed deletion can clear marker');
}));

test('Astra: a later valid native save can restore a new session after confirmed Leave',async()=>withEnvironment(async s=>{
  const vault=new Map();
  globalThis.__TAURI__={core:{invoke:async(name,args)=>{
    if(name==='online_vault_save'){vault.set(args.baseUrl,args.record);return null;}
    if(name==='online_vault_clear'){vault.delete(args.baseUrl);return null;}
    if(name==='online_vault_load')return vault.get(args.baseUrl)??null;
    throw Error('unexpected invoke command');
  }}};
  const store=createOnlineSessionStore({baseUrl:BASE,runtimeMode:'desktop'});
  assert.equal(await store.saveAsync(seat),true);
  await store.clearAsync();
  assert.equal(vault.size,0);
  assert.equal([...s.map.entries()].some(([key])=>key.endsWith(':forget-pending')),false);
  const next={...seat,side:'b'};
  assert.equal(await store.saveAsync(next),true);
  assert.deepEqual(await store.loadAsync(),next);
  assert.equal([...s.map.values()].some(value=>value.includes(TOKEN)),false);
}));

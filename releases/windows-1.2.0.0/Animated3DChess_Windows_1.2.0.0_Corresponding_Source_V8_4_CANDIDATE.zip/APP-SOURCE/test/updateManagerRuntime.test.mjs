import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {pathToFileURL, fileURLToPath} from 'node:url';
import path from 'node:path';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
let id=0;
function load(mode='desktop',version='1.2.0'){
  const source=readFileSync(path.join(root,'src/updateManager.mjs'),'utf8')
    .replace("from './updateManagerCore.mjs'",`from '${pathToFileURL(path.join(root,'src/updateManagerCore.mjs')).href}'`)
    .replaceAll('import.meta.env.MODE',JSON.stringify(mode))
    .replaceAll('__CHESS_APP_VERSION__',JSON.stringify(version));
  return import(`data:text/javascript;charset=utf-8,${encodeURIComponent(source)}#${id++}`);
}
function environment({online=false,known=null,worker=null,storeStatus='current',storeReason='NOT_MSIX_PACKAGED',storeError=false,storeAppError=false}={}){
  const values=new Map(known?[['wizard-chess-update-known-v1:microsoft-store',known]]:[]);
  globalThis.localStorage={getItem:k=>values.get(k)||null,setItem:(k,v)=>values.set(k,v),removeItem:k=>values.delete(k)};
  const invoked=[];const windowListeners={};
  globalThis.window={
    setTimeout:()=>123,clearTimeout:()=>{},setInterval:()=>123,
    wizardChess:{getGameMode:()=>online?'multi':'computer'},
    matchMedia:()=>({matches:false}),
    addEventListener:(name,fn)=>{windowListeners[name]=fn;},
    location:{reload:()=>{throw Error('unexpected reload');}},
    __TAURI__:{core:{invoke:async(command,args)=>{
      invoked.push({command,args});
      if(command==='check_store_package_updates'){
        if(storeError) throw Error('Store service offline');
        return {status:storeStatus,update_count:storeStatus==='available'?1:0,reason:storeStatus==='unavailable'?storeReason:''};
      }
      if(command==='open_apps_games_url' && args?.kind==='store-app' && storeAppError) throw Error('no Store handler');
    }}}
  };
  Object.defineProperty(globalThis,'navigator',{configurable:true,writable:true,value:{
    standalone:false,serviceWorker:worker?{
      controller:{},getRegistration:async()=>worker,addEventListener:()=>{}
    }:undefined
  }});
  return {values,invoked,windowListeners};
}
const manifest=(version)=>JSON.stringify({schemaVersion:1,product:'animated-3d-chess',channels:{'microsoft-store':{version},web:{version},pwa:{version}}});
const respond=version=>({ok:true,headers:new Map([['content-length',String(manifest(version).length)]]),text:async()=>manifest(version)});

test('Store update available only on native StoreContext response, not from manifest or cache',async()=>{
  const e=environment({storeStatus:'available',known:'9.9.9'});
  let fetched=0;globalThis.fetch=async()=>{fetched++;return respond('9.9.9');};
  const u=await load();
  assert.equal(u.getUpdateSnapshot().available,false);
  assert.equal(u.getUpdateSnapshot().latest,null);
  await u.checkForUpdates({manual:true});
  assert.equal(fetched,0,'desktop must not fetch web version manifest');
  assert.equal(u.getUpdateSnapshot().status,'current');
  assert.equal(u.getUpdateSnapshot().available,true);
  assert.equal(u.getUpdateSnapshot().latest,null,'Store API does not supply latest version string');
  u.postponeUpdate();assert.equal(u.getUpdateSnapshot().dismissed,true);
  assert.equal(await u.applyAvailableUpdate(),true);
  assert.deepEqual(e.invoked.map(x=>x.command),['check_store_package_updates','open_apps_games_url']);
  assert.deepEqual(e.invoked[1].args,{kind:'store-app'});
});
test('unpackaged app.exe never claims up to date; Store button remains usable',async()=>{
  const e=environment({storeStatus:'unavailable'});
  globalThis.fetch=async()=>{throw Error('native only');};
  const u=await load();await u.checkForUpdates({manual:true});
  assert.equal(u.getUpdateSnapshot().status,'unknown');
  assert.equal(u.getUpdateSnapshot().message,'STORE_REQUIRES_MSIX');
  assert.equal(u.getUpdateSnapshot().available,false);
  assert.equal(u.getUpdateSnapshot().latest,null);
  assert.equal(await u.openMicrosoftStore(),true);
  assert.deepEqual(e.invoked.at(-1).args,{kind:'store-app'});
});
test('installed MSIX with unavailable Store service is not mislabeled as unpackaged',async()=>{
  environment({storeStatus:'unavailable',storeReason:'STORE_QUERY_FAILED'});
  const u=await load();await u.checkForUpdates({manual:true});
  assert.equal(u.getUpdateSnapshot().message,'STORE_CHECK_UNAVAILABLE');
  assert.equal(u.getUpdateSnapshot().status,'unknown');
});
test('native Store current removes cached outdated claims',async()=>{
  const e=environment({storeStatus:'current',known:'99.0.0'});
  const u=await load();await u.checkForUpdates({manual:true});
  assert.equal(u.getUpdateSnapshot().status,'current');
  assert.equal(u.getUpdateSnapshot().available,false);
  assert.equal(u.getUpdateSnapshot().latest,null);
  assert.equal(e.values.get('wizard-chess-update-known-v1:microsoft-store'),'99.0.0', 'old cache ignored; never drives status');
});
test('Store service failure reports error, not current; no fallback to web manifest',async()=>{
  environment({storeError:true});let fetched=0;
  globalThis.fetch=async()=>{fetched++;return respond('1.0.0');};
  const u=await load();await u.checkForUpdates({manual:true});
  assert.equal(u.getUpdateSnapshot().status,'error');
  assert.equal(u.getUpdateSnapshot().available,false);
  assert.equal(fetched,0);
});
test('unknown native status cannot misreport current',async()=>{
  environment({storeStatus:'invented'});
  const u=await load();await u.checkForUpdates({manual:true});
  assert.equal(u.getUpdateSnapshot().status,'error');
  assert.equal(u.getUpdateSnapshot().available,false);
});
test('active online match prevents Store navigation even if update is available',async()=>{
  const e=environment({online:true,storeStatus:'available'});
  const u=await load();await u.checkForUpdates({manual:true});
  assert.equal(await u.applyAvailableUpdate(),false);
  assert.equal(await u.openMicrosoftStore(),false);
  assert.equal(u.getUpdateSnapshot().message,'ACTIVE_GAME');
  assert.equal(e.invoked.filter(x=>x.command==='open_apps_games_url').length,0);
});
test('OS Store URL failure uses fixed HTTPS fallback, never an arbitrary URL',async()=>{
  const e=environment({storeStatus:'unavailable',storeAppError:true});
  const u=await load();
  assert.equal(await u.openMicrosoftStore(),true);
  assert.deepEqual(e.invoked.slice(-2).map(x=>x.args),[{kind:'store-app'},{kind:'store'}]);
});
test('PWA update mechanism remains compatible and does not auto-activate worker',async()=>{
  const sent=[];
  const worker={waiting:{postMessage:obj=>sent.push(obj)},update:async()=>{},addEventListener:()=>{}};
  environment({worker});globalThis.fetch=async()=>respond('1.3.0');
  const u=await load('production');await u.checkForUpdates({manual:true});
  assert.equal(u.getUpdateSnapshot().available,true);
  assert.equal(sent.length,0);
  assert.equal(await u.applyAvailableUpdate(),true);
  assert.deepEqual(sent,[{type:'CHESS_APPLY_UPDATE'}]);
});
test('Rust Store adapter is read-only, package-identity gated and no update installer is present',()=>{
  const rust=readFileSync(path.join(root,'src-tauri/src/store_updates.rs'),'utf8');
  const lib=readFileSync(path.join(root,'src-tauri/src/lib.rs'),'utf8');
  const info=readFileSync(path.join(root,'src/InfoPanel.tsx'),'utf8');
  assert.match(rust,/GetAppAndOptionalStorePackageUpdatesAsync/);
  assert.match(rust,/Package::Current/);
  assert.match(rust,/Soldatix\.Animated3DChess/);
  assert.match(rust,/Soldatix\.Animated3DChess_ghspp2csrexvc/);
  assert.match(rust,/spawn_blocking/);
  // The pinned windows 0.62.2 crate has no windows::core::init_mta().
  assert.doesNotMatch(rust,/windows::core::init_mta\s*\(/);
  assert.match(rust,/#\[link\(name\s*=\s*"runtimeobject"\)\]/);
  assert.match(rust,/RoInitialize\(RO_INIT_MULTITHREADED\)/);
  assert.match(rust,/impl Drop for WinRtApartment/);
  assert.match(rust,/RoUninitialize\(\)/);

  assert.doesNotMatch(rust,/RequestDownloadAndInstall|TrySilentDownload|RequestDownloadStorePackageUpdates/);
  assert.match(lib,/check_store_package_updates/);
  assert.match(lib,/ms-windows-store:\/\/pdp\/\?ProductId=9MWQ5CZNLSBD/);
  assert.match(info,/STORE_REQUIRES_MSIX/);
});

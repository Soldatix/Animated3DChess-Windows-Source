import test from 'node:test';
import assert from 'node:assert/strict';
import { OnlineMultiplayerClient } from '../src/onlineMultiplayerClient.mjs';
const BASE='http://127.0.0.1:8787', CODE='ABCDEFGH23', TOKEN='T'.repeat(43);
const room=(rev,round=1,status='playing',offer=null)=>({
  code:CODE,revision:rev,round,status,rematchOfferedBy:offer,turn:'w',ply:0,moves:[],
  whiteJoined:true,blackJoined:true,fen:'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
  drawOfferedBy:null,result:status==='finished'?{winner:'w',reason:'resign'}:null,
});
class FakeWS {
  static all=[];
  constructor(){ this.handlers=new Map();this.sent=[];FakeWS.all.push(this);queueMicrotask(()=>this.emit('open',{})); }
  addEventListener(type,fn){this.handlers.set(type,[...(this.handlers.get(type)||[]),fn]);}
  emit(type,event){for(const fn of this.handlers.get(type)||[])fn(event);}
  send(data){const o=JSON.parse(data);this.sent.push(o);
    if(o.type==='auth') queueMicrotask(()=>this.emit('message',{data:JSON.stringify({type:'authenticated',side:'w',room:room(2,1,'finished')})}));}
  close(){this.emit('close',{code:1000,reason:''});}
}
const flush=()=>new Promise(resolve=>setTimeout(resolve,15));
function environment() {
  const history=[], saved=[];
  const store={requiresAsyncLookup:true,loadAsync:async()=>null,
    saveAsync:async(record)=>{saved.push({...record});return true;},
    clear(){},clearAsync:async()=>true};
  const fetchImpl=async(url,opts)=>{
    const input=opts.body?JSON.parse(opts.body):null;
    history.push({url,input,authorization:opts.headers?.authorization});
    if(url.endsWith('/v1/rooms'))return response({ok:true,code:CODE,side:'w',token:TOKEN,room:room(1,1,'waiting')},201);
    if(url.endsWith('/rematch-offer')) return response({ok:true,side:'w',room:room(3,1,'finished','w')});
    if(url.endsWith('/rematch-response'))return response({ok:true,side:'b',room:room(4,2)});
    if(url.endsWith('/state')) return response({ok:true,side:'b',room:room(4,2)});
    if(url.endsWith('/move'))return response({ok:true,side:'b',room:room(5,2)});
    throw Error('UNEXPECTED_URL:'+url);
  };
  return {history,saved,store,fetchImpl};
}
const response=(data,status=200)=>({ok:status<400,status,json:async()=>data});
test('v1.2 authenticated rematch rotates seats and persists new side in vault',async()=>{
  FakeWS.all.length=0;
  const e=environment(), seen=[];
  const c=new OnlineMultiplayerClient({baseUrl:BASE,sessionStore:e.store,fetchImpl:e.fetchImpl,
    WebSocketImpl:FakeWS,onRoom:room=>seen.push(room)});
  try {
    await c.create('w');await flush();
    assert.equal(c.status,'connected');
    assert.equal(FakeWS.all[0].sent[0].rematchV12,true);
    assert.equal(c.getPublicState().room.round,1);
    await c.action('rematch-offer');
    assert.equal(e.history.at(-1).input.expectedRound,1);
    await c.action('rematch-response',{accept:true});
    assert.equal(e.history.at(-1).input.expectedRound,1);
    assert.equal(c.getPublicState().side,'b');
    assert.equal(c.getPublicState().room.round,2);
    await flush();
    assert.equal(e.saved.at(-1).side,'b');
    assert.equal(JSON.stringify(c.getPublicState()).includes(TOKEN),false);
    assert.equal(seen.at(-1).round,2);
  } finally {c.close();}
});
test('v1.2 rejects unknown rematch action; server receives expectedRound for requests',async()=>{
  const e=environment();
  const c=new OnlineMultiplayerClient({baseUrl:BASE,sessionStore:e.store,fetchImpl:e.fetchImpl,WebSocketImpl:FakeWS});
  try {await c.create('w');await flush();
    await assert.rejects(c.action('evil-command'),/invalid-action/);
    await c.action('rematch-offer');
    assert.equal(e.history.at(-1).input.expectedRound,1);
  }finally{c.close();}
});
test('v1.2 treats roundless v1.1 room as round one',async()=>{
  const e=environment();
  const c=new OnlineMultiplayerClient({baseUrl:BASE,sessionStore:e.store,fetchImpl:e.fetchImpl,WebSocketImpl:FakeWS});
  try{await c.create('w');await flush();
    const legacy={...room(3,1)};delete legacy.round;
    FakeWS.all.at(-1).emit('message',{data:JSON.stringify({type:'state',side:'w',room:legacy})});
    assert.equal(c.getPublicState().room.revision,3);
    assert.equal(c.getPublicState().room.round,undefined);
  }finally{c.close();}
});

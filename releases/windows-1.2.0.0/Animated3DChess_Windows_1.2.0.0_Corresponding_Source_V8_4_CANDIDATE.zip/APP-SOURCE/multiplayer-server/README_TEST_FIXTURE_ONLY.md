# Local game module for deterministic Node tests

This game.mjs is included because two Windows client regression tests import it.
It is a historical V1.1 test fixture, NOT the deployed V1.2 production Worker.
Production V1.2 Worker revision must be independently identified before release.
